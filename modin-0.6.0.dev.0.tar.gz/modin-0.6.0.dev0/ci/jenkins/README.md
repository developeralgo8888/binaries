Jenkins CI

Please run everything in Docker!
