Contact
=======

Mailing List
------------

https://groups.google.com/forum/#!forum/modin-dev

General questions, potential contributors, and ideas should be directed to the
`developer mailing list`_. It is an open Google Group, so feel free to join anytime! If
you are unsure about where to ask or post something, the mailing list is a good place to
ask as well.

Issues
------

https://github.com/modin-project/modin/issues

Bug reports and feature requests should be directed to the issues_ page of the Modin
GitHub repo.

.. _developer mailing list: https://groups.google.com/forum/#!forum/modin-dev
.. _issues: https://github.com/modin-project/modin/issues
